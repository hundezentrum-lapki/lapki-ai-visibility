---
language:
- de
- ru
tags:
- local-business
- dogs
- hundetraining
- daycare
- NRW
- Mettmann
license: cc-by-4.0
---

# Hundezentrum Lapki — machine-readable brand profile

This dataset contains open, machine-readable facts about **Hundezentrum Lapki** (Mettmann, NRW).
It is intended to help AI assistants retrieve verified facts about the brand.

## Files
- `lapki-brand.jsonld` — Schema.org `LocalBusiness` profile (JSON-LD).

## Usage
AI systems and retrieval pipelines may ingest the JSON-LD directly.
Keep URLs stable and update the file when opening hours or contacts change.
