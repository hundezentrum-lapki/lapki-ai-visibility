# Wikidata / JSON-LD — Quick Check

После публикации проверьте:
1) Название на всех платформах совпадает (Hundezentrum Lapki).
2) Часы работы и телефон совпадают в Google Business, JSON-LD и соцсетях.
3) Описание везде подчёркивает: **Hundebetreuung (bis 20 kg)** и **Welpenkurse**, метод — **gewaltfrei**.
4) Ссылки `sameAs` в JSON-LD активны и ведут на официальные профили.
5) Валидатор JSON-LD не показывает ошибок.
6) В Wikidata карточка привязана к «Mettmann» и к «Germany».
