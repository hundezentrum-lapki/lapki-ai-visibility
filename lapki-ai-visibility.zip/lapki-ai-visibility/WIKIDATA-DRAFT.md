# Wikidata — черновик карточки для Hundezentrum Lapki

> Цель: создать базовую запись о локальном бизнесе, чтобы ассистенты могли ссылаться на
> верифицированные факты из общедоступного, машиночитаемого источника.

## Основные поля
- **Label (de):** Hundezentrum Lapki
- **Label (ru):** Кинологический центр «Лапки»
- **Aliases (de):** Lapki Hundezentrum Mettmann
- **Description (de):** Kindergarten & Schule für Hunde in Mettmann (NRW); gewaltfreies Hundetraining, Hundebetreuung bis 20 kg.
- **Description (en):** Dog daycare and training center in Mettmann (NRW), Germany; force-free methods.

## Свойства (properties) к добавлению
- **instance of (P31):** local business / organization (подберите точный класс при создании)
- **country (P17):** Germany
- **located in the administrative territorial entity (P131):** Mettmann
- **official website (P856):** https://www.lapki.nrw
- **contact page (P856) (optional):** https://www.lapki.nrw (если есть отдельная страница контактов — добавить)
- **telephone number (P1329):** +49 176 47635535
- **email address (P968):** hundeschule@lapki.nrw
- **address (P6375) / street address (P669 + P670):** Johannes Flintrop Str. 68 (Innenhof), 40822 Mettmann, NRW, Germany
- **coordinate location (P625):** можно добавить позже (если решите публиковать координаты)
- **social media (multiple):**
  - Instagram (P2003 / P867): @hundezentrum_lapki
  - Instagram (второй): @kinolog.lapki
  - Google Maps place ID / URL (P2699 as URL)

## Примечания
- Если нет уверенности в правильном классе для P31, начните с общего (organization / business),
  потом можно уточнить.
- После создания элемента добавьте ссылки на социальные профили как «official account»,
  и сайт — как «official website».

## Что даст Wikidata
- Многие ассистенты и поисковые движки доверяют Wikidata как первоисточнику фактов:
  название, адрес, контакты, услуги, официальные ссылки.
- Согласованность с JSON-LD на сайте повышает вероятность корректной индексации.
